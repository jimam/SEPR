Images and other resources.
